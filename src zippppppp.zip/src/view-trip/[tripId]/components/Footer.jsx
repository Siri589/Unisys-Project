import React from 'react'

function Footer() {
  return (
    <div>
        <h4>developed by Siri P</h4>
    </div>
  )
}

export default Footer