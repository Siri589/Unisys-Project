import React, { useState } from 'react';
import './fertilizer.css';

const FertilizerRecommendation = () => {
    const [cropType, setCropType] = useState('');
    const [growthStage, setGrowthStage] = useState('');
    const [soilTexture, setSoilTexture] = useState('');
    const [moisture, setMoisture] = useState('');
    const [ph, setPh] = useState('');
    const [nutrients, setNutrients] = useState('');
    const [irrigation, setIrrigation] = useState(false);
    const [previousFertilizers, setPreviousFertilizers] = useState('');
    const [recommendations, setRecommendations] = useState(null);
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage('');
        setRecommendations(null);

        // Basic validation
        if (!cropType || !growthStage || !soilTexture || !moisture || !ph || !nutrients) {
            setErrorMessage('Please fill all required fields.');
            return;
        }

        if (moisture < 0 || moisture > 100) {
            setErrorMessage('Soil moisture must be between 0 and 100%.');
            return;
        }

        setLoading(true);

        try {
            // Mock AI API call
            const response = await fetch('AIzaSyBIkDdderWjsuqENvq_knVjAQLODhgTt3Y', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    cropType,
                    growthStage,
                    soilTexture,
                    moisture,
                    ph,
                    nutrients,
                    irrigation,
                    previousFertilizers: previousFertilizers.split(',').map(f => f.trim())
                })
            });

            const data = await response.json();

            if (!data || !data['Recommended Fertilizers']) {
                throw new Error('Unexpected response format');
            }

            setRecommendations({
                fertilizers: data['Recommended Fertilizers'] || ['No specific fertilizers recommended'],
                applicationMethods: data['Application Methods and Amounts'] || { 'No methods': { Method: 'N/A', Amount: 'N/A' } },
                timing: data['Recommended Timing'] || 'No timing recommendation available'
            });
        } catch (error) {
            setErrorMessage('Failed to fetch recommendations. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fertilizer-recommendation">
            <h1>Fertilizer Recommendation System</h1>
            <form onSubmit={handleSubmit}>
                {errorMessage && <div className="error-message">{errorMessage}</div>}
                <div className="form-group">
                    <label>Crop Type:</label>
                    <input type="text" value={cropType} onChange={(e) => setCropType(e.target.value)} placeholder="e.g., Wheat" required />
                </div>
                <div className="form-group">
                    <label>Growth Stage:</label>
                    <input type="text" value={growthStage} onChange={(e) => setGrowthStage(e.target.value)} placeholder="e.g., Vegetative" required />
                </div>
                <div className="form-group">
                    <label>Soil Texture:</label>
                    <input type="text" value={soilTexture} onChange={(e) => setSoilTexture(e.target.value)} placeholder="e.g., Sandy Loam" required />
                </div>
                <div className="form-group">
                    <label>Soil Moisture (%):</label>
                    <input type="number" value={moisture} onChange={(e) => setMoisture(e.target.value)} placeholder="e.g., 40" required />
                </div>
                <div className="form-group">
                    <label>Soil pH Level:</label>
                    <input type="number" step="0.1" value={ph} onChange={(e) => setPh(e.target.value)} placeholder="e.g., 6.5" required />
                </div>
                <div className="form-group">
                    <label>Soil Nutrients:</label>
                    <textarea value={nutrients} onChange={(e) => setNutrients(e.target.value)} placeholder="e.g., Nitrogen: High, Phosphorus: Low" required></textarea>
                </div>
                <div className="form-group">
                    <label>Irrigation Available:</label>
                    <input type="checkbox" checked={irrigation} onChange={(e) => setIrrigation(e.target.checked)} />
                </div>
                <div className="form-group">
                    <label>Previously Used Fertilizers:</label>
                    <input type="text" value={previousFertilizers} onChange={(e) => setPreviousFertilizers(e.target.value)} placeholder="e.g., Urea, DAP" />
                </div>
                <button type="submit" disabled={loading}>Generate Recommendations</button>
            </form>

            {loading && <div className="loading">Loading...</div>}

            {recommendations && (
                <div className="recommendations">
                    <h2>Recommendations</h2>
                    <div>
                        <h3>Fertilizers:</h3>
                        <ul>
                            {recommendations.fertilizers.map((fertilizer, index) => (
                                <li key={index}>{fertilizer}</li>
                            ))}
                        </ul>
                    </div>
                    <div>
                        <h3>Application Methods:</h3>
                        {Object.entries(recommendations.applicationMethods).map(([key, value]) => (
                            <div key={key}>
                                <strong>{key}</strong>: {value.Method} - {value.Amount}
                            </div>
                        ))}
                    </div>
                    <div>
                        <h3>Timing:</h3>
                        <p>{recommendations.timing}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default FertilizerRecommendation;











































































// import React, { useState } from 'react';
// import './fertilizer.css';
// import { chatSession } from '../service/AIModal.jsx';

// function FertilizerRecommendation() {
//   const [cropType, setCropType] = useState('');
//   const [growthStage, setGrowthStage] = useState('');
//   const [soilTexture, setSoilTexture] = useState('');
//   const [phLevel, setPhLevel] = useState('');
//   const [nitrogen, setNitrogen] = useState('');
//   const [phosphorus, setPhosphorus] = useState('');
//   const [potassium, setPotassium] = useState('');
//   const [moisture, setMoisture] = useState('');
//   const [organicMatter, setOrganicMatter] = useState('');
//   const [region, setRegion] = useState('');
//   const [purpose, setPurpose] = useState('');
//   const [fertilizerPreference, setFertilizerPreference] = useState('');
//   const [budget, setBudget] = useState('');
//   const [prevFertilizers, setPrevFertilizers] = useState([]);
//   const [fertilizerFeedback, setFertilizerFeedback] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [recommendations, setRecommendations] = useState(null);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);
//     setRecommendations(null); // Reset recommendations for a new submission

//     const aiPrompt = `Based on the farmer's input:
//       - Crop Type: ${cropType || 'Not specified'}
//       - Growth Stage: ${growthStage}
//       - Soil Texture: ${soilTexture}
//       - Soil pH Level: ${phLevel}
//       - Nitrogen Content: ${nitrogen} mg/kg
//       - Phosphorus Content: ${phosphorus} mg/kg
//       - Potassium Content: ${potassium} mg/kg
//       - Soil Moisture Level: ${moisture}%
//       - Organic Matter Content: ${organicMatter}%
//       - Region/Place: ${region || 'Not specified'}
//       - Purpose of Fertilizer Use: ${purpose}
//       - Fertilizer Preference: ${fertilizerPreference}
//       - Budget for Fertilizer: ${budget || 'No budget specified'}
//       - Previously Used Fertilizers: ${prevFertilizers.join(', ') || 'None specified'}
//       - Fertilizer Performance Feedback: ${fertilizerFeedback || 'No feedback provided'}
  
//       Focus on sustainable farming practices and provide:
//       1. Recommended fertilizers.
//       2. Application methods and amounts.
//       3. Environmental benefits and precautions.
//       4. Expected crop improvements.
//       5. Tips for sustainable use.`;

//     try {
//       const result = await chatSession.sendMessage(aiPrompt);
//       const data = await result.response.text();

//       // Parse the AI response directly into recommendations
//       const parsedData = JSON.parse(data);

//       setRecommendations({
//         fertilizers: parsedData['Recommended Fertilizers'] || [],
//         applicationMethods: parsedData['Application Methods and Amounts'] || {},
//         environmentalBenefits: parsedData['Environmental Benefits'] || [],
//         precautions: parsedData['Precautions'] || [],
//         cropImprovements: parsedData['Expected Crop Improvements'] || [],
//         sustainableTips: parsedData['Tips for Sustainable Use'] || [],
//       });
//     } catch (error) {
//       console.error('Error fetching recommendations:', error);
//       setRecommendations({ error: 'Unable to generate recommendations. Please try again later.' });
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="container">
//       <h6>Fertilizer Recommendation Form</h6>
//       <form onSubmit={handleSubmit}>
//         {/* Crop Details */}
//         <label>Crop Type:</label>
//         <input type="text" value={cropType} onChange={(e) => setCropType(e.target.value)} />

//         <label>Growth Stage:</label>
//         <select value={growthStage} onChange={(e) => setGrowthStage(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Germination">Germination</option>
//           <option value="Vegetative">Vegetative</option>
//           <option value="Flowering">Flowering</option>
//           <option value="Fruiting">Fruiting</option>
//           <option value="Harvesting">Harvesting</option>
//         </select>

//         {/* Soil and Environment Inputs */}
//         <label>Soil Texture:</label>
//         <select value={soilTexture} onChange={(e) => setSoilTexture(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Clay">Clay</option>
//           <option value="Loam">Loam</option>
//           <option value="Sand">Sand</option>
//         </select>

//         <label>Soil pH Level:</label>
//         <select value={phLevel} onChange={(e) => setPhLevel(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Acidic">Acidic</option>
//           <option value="Neutral">Neutral</option>
//           <option value="Alkaline">Alkaline</option>
//         </select>

//         <label>Nitrogen (mg/kg):</label>
//         <input type="number" value={nitrogen} onChange={(e) => setNitrogen(e.target.value)} />

//         <label>Phosphorus (mg/kg):</label>
//         <input type="number" value={phosphorus} onChange={(e) => setPhosphorus(e.target.value)} />

//         <label>Potassium (mg/kg):</label>
//         <input type="number" value={potassium} onChange={(e) => setPotassium(e.target.value)} />

//         <label>Soil Moisture (%):</label>
//         <input type="number" value={moisture} onChange={(e) => setMoisture(e.target.value)} />

//         <label>Organic Matter (%):</label>
//         <input type="number" value={organicMatter} onChange={(e) => setOrganicMatter(e.target.value)} />

//         <label>Region/Place:</label>
//         <input type="text" value={region} onChange={(e) => setRegion(e.target.value)} />

//         {/* Fertilizer Preferences */}
//         <label>Purpose of Fertilizer Use:</label>
//         <select value={purpose} onChange={(e) => setPurpose(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Increase Yield">Increase Yield</option>
//           <option value="Boost Growth">Boost Growth</option>
//           <option value="Correct Nutrient Deficiency">Correct Nutrient Deficiency</option>
//           <option value="Improve Soil Health">Improve Soil Health</option>
//         </select>

//         <label>Fertilizer Preference:</label>
//         <select value={fertilizerPreference} onChange={(e) => setFertilizerPreference(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Organic">Organic</option>
//           <option value="Inorganic">Inorganic</option>
//           <option value="Biofertilizer">Biofertilizer</option>
//           <option value="No Preference">No Preference</option>
//         </select>

//         <label>Budget (in local currency):</label>
//         <input type="number" value={budget} onChange={(e) => setBudget(e.target.value)} />

//         <label>Previously Used Fertilizers:</label>
//         <input
//           type="text"
//           value={prevFertilizers}
//           onChange={(e) => setPrevFertilizers(e.target.value.split(',').map(f => f.trim()))}
//         />

//         <label>Fertilizer Performance Feedback:</label>
//         <textarea
//           value={fertilizerFeedback}
//           onChange={(e) => setFertilizerFeedback(e.target.value)}
//         ></textarea>

//         <button type="submit" disabled={loading}>
//           {loading ? 'Generating...' : 'Get Recommendations'}
//         </button>
//       </form>

//       {/* Display Recommendations */}
//       {recommendations && (
//         <div className="recommendations">
//           <h3>Recommendations</h3>
//           {recommendations.error ? (
//             <p style={{ color: 'red' }}>{recommendations.error}</p>
//           ) : (
//             <>
//               <h4>Fertilizer Recommendations</h4>
//               <ul>
//                 {recommendations.fertilizers.map((fertilizer, index) => (
//                   <li key={index}>{fertilizer}</li>
//                 ))}
//               </ul>

//               <h4>Application Methods and Amounts</h4>
//               <ul>
//                 {Object.entries(recommendations.applicationMethods).map(([fertilizer, details], index) => (
//                   <li key={index}>
//                     <p><strong>{fertilizer}</strong></p>
//                     <p>Method: {details.Method || 'N/A'}</p>
//                     <p>Amount: {details.Amount || 'N/A'}</p>
//                   </li>
//                 ))}
//               </ul>

//               <h4>Environmental Benefits</h4>
//               <ul>
//                 {recommendations.environmentalBenefits.map((benefit, index) => (
//                   <li key={index}>{benefit}</li>
//                 ))}
//               </ul>

//               <h4>Crop Improvements</h4>
//               <ul>
//                 {recommendations.cropImprovements.map((improvement, index) => (
//                   <li key={index}>{improvement}</li>
//                 ))}
//               </ul>

//               <h4>Sustainable Tips</h4>
//               <ul>
//                 {recommendations.sustainableTips.map((tip, index) => (
//                   <li key={index}>{tip}</li>
//                 ))}
//               </ul>
//             </>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }

// export default FertilizerRecommendation;



















































































// import React, { useState } from 'react';
// import './fertilizer.css';
// import { chatSession } from '../service/AIModal.jsx';

// function FertilizerRecommendation() {
//   const [cropType, setCropType] = useState('');
//   const [growthStage, setGrowthStage] = useState('');
//   const [soilTexture, setSoilTexture] = useState('');
//   const [phLevel, setPhLevel] = useState('');
//   const [nitrogen, setNitrogen] = useState('');
//   const [phosphorus, setPhosphorus] = useState('');
//   const [potassium, setPotassium] = useState('');
//   const [moisture, setMoisture] = useState('');
//   const [organicMatter, setOrganicMatter] = useState('');
//   const [region, setRegion] = useState('');
//   const [purpose, setPurpose] = useState('');
//   const [fertilizerPreference, setFertilizerPreference] = useState('');
//   const [budget, setBudget] = useState('');
//   const [prevFertilizers, setPrevFertilizers] = useState([]);
//   const [fertilizerFeedback, setFertilizerFeedback] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [recommendations, setRecommendations] = useState(null);
//   const [errorMessage, setErrorMessage] = useState('');

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setErrorMessage('');

//     // Validation: Check if at least one field is filled
//     if (
//       !cropType &&
//       !growthStage &&
//       !soilTexture &&
//       !phLevel &&
//       !nitrogen &&
//       !phosphorus &&
//       !potassium &&
//       !moisture &&
//       !organicMatter &&
//       !region &&
//       !purpose &&
//       !fertilizerPreference &&
//       !budget &&
//       prevFertilizers.length === 0 &&
//       !fertilizerFeedback
//     ) {
//       setErrorMessage('Please fill at least one detail to get recommendations.');
//       return;
//     }

//     setLoading(true);
//     setRecommendations(null);

//     const aiPrompt = `Based on the farmer's input:
//       - Crop Type: ${cropType || 'Not specified'}
//       - Growth Stage: ${growthStage || 'Not specified'}
//       - Soil Texture: ${soilTexture || 'Not specified'}
//       - Soil pH Level: ${phLevel || 'Not specified'}
//       - Nitrogen Content: ${nitrogen || 'Not specified'} mg/kg
//       - Phosphorus Content: ${phosphorus || 'Not specified'} mg/kg
//       - Potassium Content: ${potassium || 'Not specified'} mg/kg
//       - Soil Moisture Level: ${moisture || 'Not specified'}%
//       - Organic Matter Content: ${organicMatter || 'Not specified'}%
//       - Region/Place: ${region || 'Not specified'}
//       - Purpose of Fertilizer Use: ${purpose || 'Not specified'}
//       - Fertilizer Preference: ${fertilizerPreference || 'Not specified'}
//       - Budget for Fertilizer: ${budget || 'No budget specified'}
//       - Previously Used Fertilizers: ${prevFertilizers.join(', ') || 'None specified'}
//       - Fertilizer Performance Feedback: ${fertilizerFeedback || 'No feedback provided'}
      
//       Provide recommendations for sustainable farming practices.`;

//     try {
//       const result = await chatSession.sendMessage(aiPrompt);
//       const data = await result.response.text();

//       // Parse response into recommendations
//       const parsedData = JSON.parse(data);

//       setRecommendations({
//         fertilizers: parsedData['Recommended Fertilizers'] || [],
//         applicationMethods: parsedData['Application Methods and Amounts'] || {},
//         environmentalBenefits: parsedData['Environmental Benefits'] || [],
//         precautions: parsedData['Precautions'] || [],
//         cropImprovements: parsedData['Expected Crop Improvements'] || [],
//         sustainableTips: parsedData['Tips for Sustainable Use'] || [],
//       });
//     } catch (error) {
//       console.error('Error fetching recommendations:', error);
//       setRecommendations({ error: 'Unable to generate recommendations. Please try again later.' });
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="container">
//       <h10>Fertilizer Recommendation Form</h10>
//       {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
//       <form onSubmit={handleSubmit}>
//         <label>Crop Type:</label>
//         <input type="text" value={cropType} onChange={(e) => setCropType(e.target.value)} />

//         <label>Growth Stage:</label>
//         <select value={growthStage} onChange={(e) => setGrowthStage(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Germination">Germination</option>
//           <option value="Vegetative">Vegetative</option>
//           <option value="Flowering">Flowering</option>
//           <option value="Fruiting">Fruiting</option>
//           <option value="Harvesting">Harvesting</option>
//         </select>

//         <label>Soil Texture:</label>
//         <select value={soilTexture} onChange={(e) => setSoilTexture(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Clay">Clay</option>
//           <option value="Loam">Loam</option>
//           <option value="Sand">Sand</option>
//         </select>

//         <label>Soil pH Level:</label>
//         <select value={phLevel} onChange={(e) => setPhLevel(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Acidic">Acidic</option>
//           <option value="Neutral">Neutral</option>
//           <option value="Alkaline">Alkaline</option>
//         </select>

//         <label>Nitrogen (mg/kg):</label>
//         <input type="number" value={nitrogen} onChange={(e) => setNitrogen(e.target.value)} />

//         <label>Phosphorus (mg/kg):</label>
//         <input type="number" value={phosphorus} onChange={(e) => setPhosphorus(e.target.value)} />

//         <label>Potassium (mg/kg):</label>
//         <input type="number" value={potassium} onChange={(e) => setPotassium(e.target.value)} />

//         <label>Soil Moisture (%):</label>
//         <input type="number" value={moisture} onChange={(e) => setMoisture(e.target.value)} />

//         <label>Organic Matter (%):</label>
//         <input type="number" value={organicMatter} onChange={(e) => setOrganicMatter(e.target.value)} />

//         <label>Region/Place:</label>
//         <input type="text" value={region} onChange={(e) => setRegion(e.target.value)} />

//         <label>Purpose of Fertilizer Use:</label>
//         <select value={purpose} onChange={(e) => setPurpose(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Increase Yield">Increase Yield</option>
//           <option value="Boost Growth">Boost Growth</option>
//           <option value="Correct Nutrient Deficiency">Correct Nutrient Deficiency</option>
//           <option value="Improve Soil Health">Improve Soil Health</option>
//         </select>

//         <label>Fertilizer Preference:</label>
//         <select value={fertilizerPreference} onChange={(e) => setFertilizerPreference(e.target.value)}>
//           <option value="">Select...</option>
//           <option value="Organic">Organic</option>
//           <option value="Inorganic">Inorganic</option>
//           <option value="Biofertilizer">Biofertilizer</option>
//           <option value="No Preference">No Preference</option>
//         </select>

//         <label>Budget (in local currency):</label>
//         <input type="number" value={budget} onChange={(e) => setBudget(e.target.value)} />

//         <label>Previously Used Fertilizers:</label>
//         <input
//           type="text"
//           value={prevFertilizers}
//           onChange={(e) => setPrevFertilizers(e.target.value.split(',').map(f => f.trim()))}
//         />

//         <label>Fertilizer Performance Feedback:</label>
//         <textarea
//           value={fertilizerFeedback}
//           onChange={(e) => setFertilizerFeedback(e.target.value)}
//         ></textarea>

//         <button type="submit" disabled={loading}>
//           {loading ? 'Generating...' : 'Get Recommendations'}
//         </button>
//       </form>

//       {recommendations && (
//         <div className="recommendations">
//           <h3>Recommendations</h3>
//           {recommendations.error ? (
//             <p style={{ color: 'red' }}>{recommendations.error}</p>
//           ) : (
//             <>
//               <h4>Fertilizer Recommendations</h4>
//               <ul>
//                 {recommendations.fertilizers.map((fertilizer, index) => (
//                   <li key={index}>{fertilizer}</li>
//                 ))}
//               </ul>
//               <h4>Additional Information</h4>
//               {/* Add parsed data display here */}
//             </>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }
// export default FertilizerRecommendation;